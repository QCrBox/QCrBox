"""
This module contains file conversions of crystallographic formats from and to cif
"""
