"""
This module contains classes and functions to execute crystallographic software with input variables
"""
